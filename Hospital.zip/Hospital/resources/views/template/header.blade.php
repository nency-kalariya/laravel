<h1>Ever Green Hospital</h1>
@include('template.menu')