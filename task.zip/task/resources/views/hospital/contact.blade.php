@extends('template.layout')
@section('content')
    <h1>Contact page</h1>
@endsection
