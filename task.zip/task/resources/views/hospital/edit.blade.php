@extends('template.layout')
@section('content')
<h1>Edit </h1>

<form action="{{route('hospital.update',$hospital->id)}}" method="post">
    @csrf
    @method('put')
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">Name</label>
      <input type="text" class="form-control"  name="name" value="{{$hospital->name}}">

    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Mobile</label>
      <input type="text" class="form-control" name ="mobile" value="{{$hospital->mobile}}">
    </div>
    <div class="form-floating">
        <textarea class="form-control" placeholder="Leave a comment here"  name="disease" id="floatingTextarea" >{{$hospital->disease}}</textarea>
        <label for="floatingTextarea">Disease</label>
        <script>
            ClassicEditor
                .create( document.querySelector( '#editor' ) )
                .catch( error => {
                    console.error( error );
                } );
        </script>

      </div>
    <div class="mb-3 ">
        <label for="floatingTextarea">Medicines</label>
        <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" name="medicines" >{{$hospital->medicines}}</textarea>

    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>


@endsection
@section('script-tag')
<script src="https://cdn.ckeditor.com/ckeditor5/41.3.0/classic/ckeditor.js"></script>
@endsection
