@extends('template.layout')
@section('content')
<h1>Sign in</h1>

<form action="{{route('hospital.store')}}" method="post">
    @csrf
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">Name</label>
      <input type="text" class="form-control" name="name">

    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Mobile</label>
      <input type="text" class="form-control" name="mobile">
    </div>
    <div class="mb-3">
        <label for="floatingTextarea">Disease</label>
        <textarea class="form-control" placeholder="Leave a comment here" id="editor" name="disease"></textarea>

        <script>
            ClassicEditor
                .create( document.querySelector( '#editor' ) )
                .catch( error => {
                    console.error( error );
                } );
        </script>

      </div>
    <div class="mb-3 ">
        <label for="exampleInputPassword1" class="form-label">Medicines</label>
        <textarea class="form-control" placeholder="Leave a comment here" id="editor" name="medicines"></textarea>

    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>


@endsection
@section('script-tag')
<script src="https://cdn.ckeditor.com/ckeditor5/41.3.0/classic/ckeditor.js"></script>
@endsection
