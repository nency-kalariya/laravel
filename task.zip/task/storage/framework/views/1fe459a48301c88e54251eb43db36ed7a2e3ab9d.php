<?php $__env->startSection('content'); ?>
<h1>Edit </h1>

<form action="<?php echo e(route('hospital.update',$hospital->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">Name</label>
      <input type="text" class="form-control"  name="name" value="<?php echo e($hospital->name); ?>">

    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Mobile</label>
      <input type="text" class="form-control" name ="mobile" value="<?php echo e($hospital->mobile); ?>">
    </div>
    <div class="form-floating">
        <textarea class="form-control" placeholder="Leave a comment here"  name="disease" id="floatingTextarea" ><?php echo e($hospital->disease); ?></textarea>
        <label for="floatingTextarea">Disease</label>
        <script>
            ClassicEditor
                .create( document.querySelector( '#editor' ) )
                .catch( error => {
                    console.error( error );
                } );
        </script>

      </div>
    <div class="mb-3 ">
        <label for="floatingTextarea">Medicines</label>
        <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" name="medicines" ><?php echo e($hospital->medicines); ?></textarea>

    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-tag'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/41.3.0/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\task\resources\views/hospital/edit.blade.php ENDPATH**/ ?>