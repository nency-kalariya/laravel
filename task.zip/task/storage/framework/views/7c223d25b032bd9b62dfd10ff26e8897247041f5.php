<?php $__env->startSection('content'); ?>
<h1>Sign in</h1>

<form action="<?php echo e(route('hospital.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">Name</label>
      <input type="text" class="form-control" name="name">

    </div>
    <div class="mb-3">
      <label for="exampleInputPassword1" class="form-label">Mobile</label>
      <input type="text" class="form-control" name="mobile">
    </div>
    <div class="mb-3">
        <label for="floatingTextarea">Disease</label>
        <textarea class="form-control" placeholder="Leave a comment here" id="editor" name="disease"></textarea>

        <script>
            ClassicEditor
                .create( document.querySelector( '#editor' ) )
                .catch( error => {
                    console.error( error );
                } );
        </script>

      </div>
    <div class="mb-3 ">
        <label for="exampleInputPassword1" class="form-label">Medicines</label>
        <input type="text" class="form-control" name="medicines">
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-tag'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/41.3.0/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\task\resources\views/hospital/signin.blade.php ENDPATH**/ ?>