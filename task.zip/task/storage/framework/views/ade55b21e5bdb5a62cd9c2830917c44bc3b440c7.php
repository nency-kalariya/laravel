<?php $__env->startSection('content'); ?>
    <h1>this is index page</h1>
    <table class="table table-striped table-bordered tale-hover">
		<thead class="thead-dark">
			<tr>
				<th>ID</th>
				<th>patients name</th>
				<th>edit</th>
				<th>delete</th>
			</tr>
		</thead>
		<tbody>
			<?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<td><?php echo e($patient->id); ?></td>
                <td><a href="<?php echo e(route('hospital.show', $patient->id)); ?>">
                    <?php echo e($patient->name); ?>	</td>
                <td>Edit</td>
				<td>
                    <form action="<?php echo e(route('hospital.destroy',$patient->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="submit" class="btn btn-danger" value="Trash">
                        </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			

			<?php endif; ?>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\task\resources\views/hospital/index.blade.php ENDPATH**/ ?>